import re

password = input("Enter Password: ")

score = 0

if len(password) >= 8:
    score += 1

if re.search("[A-Z]", password):
    score += 1

if re.search("[a-z]", password):
    score += 1

if re.search("[0-9]", password):
    score += 1

if re.search("[@#$%^&*!]", password):
    score += 1

print("\nPassword Analysis")

if score <= 2:
    print("Weak Password")
elif score <= 4:
    print("Medium Password")
else:
    print("Strong Password")

if score < 5:
    print("\nSuggested Password:")
    print(password + "@123")